import "package:flutter/material.dart";

import 'package:flutter/material.dart';

import '../shared/menu_drawer.dart';
import '../shared/menu_bottom.dart';
class IntroScreen extends StatelessWidget {
  const IntroScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return (Scaffold(appBar: AppBar(title: Text('Madhav Fitness'),backgroundColor: Colors.blueGrey),
    drawer: MenuDrawer(),
    bottomNavigationBar: MenuBottom(),
    
    
    
    body: Container(
      decoration: BoxDecoration(
        image: DecorationImage(
          image: NetworkImage('https://images.unsplash.com/photo-1526506118085-60ce8714f8c5?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8Z3ltfGVufDB8fDB8fA%3D%3D&auto=format&fit=crop&w=500&q=60'),
          fit: BoxFit.cover,
        )
      ),
      child: Center(child: Container(
        
        padding : EdgeInsets.all(20),
        
        decoration: BoxDecoration(
          borderRadius: BorderRadius.all(Radius.circular(20)),
        color: Colors.white70
        ),
        child: Text('Exercise is king. Nutrition is queen. \n Put them together and you’ve got a kingdom.',
        textAlign: TextAlign.center,
        style: TextStyle(
          
          fontSize: 22,
          shadows: [
            Shadow(
              offset: Offset(1.0, 1.0),
              blurRadius: 2.0,
              color: Colors.blueGrey
            )
          ],
          color: Colors.black87
          
        ),)))),
    
    )

    );
  }
}

