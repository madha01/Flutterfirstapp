import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:madhav_fitness/shared/menu_drawer.dart';

import '../shared/menu_bottom.dart';
class Bmiscreen extends StatefulWidget {
  const Bmiscreen({super.key});

  @override
  State<Bmiscreen> createState() => _BmiscreenState();
}

class _BmiscreenState extends State<Bmiscreen> {
  final TextEditingController txtHeight = TextEditingController();
   final TextEditingController txtWeight = TextEditingController();
  final double fontsize = 18;
  String result = '';
  bool isMetric = true;
  bool isImperial = false;
  double? height;
  double? weight;
  late List<bool> isSelected;
  String heightmessage = '';
  String Weightmessage = '';

  @override
  void initState() {
    isSelected = [isMetric,isImperial];
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    heightmessage = 'Please insert your height in ' +  ((isMetric) ? 'meters' : 'inches');
    Weightmessage = 'Please insert your weight in ' +  ((isMetric)?'kilos':'pounds');
    return Scaffold(
      drawer:MenuDrawer(),
       bottomNavigationBar: MenuBottom(),
      appBar: AppBar(title: Text('BMI Calculator',),
      
      backgroundColor: Colors.blueGrey),
     
      backgroundColor: Color.fromARGB(255, 218, 216, 216),
      body:SingleChildScrollView(
        child: Column(
          children: [
            ToggleButtons(children:[
              Padding(padding: const EdgeInsets.symmetric(horizontal:16),
              child: Text('Metric',style:TextStyle(fontSize: fontsize)),
              ),
               Padding(padding: const EdgeInsets.symmetric(horizontal:16),
              child: Text('Imperial',style:TextStyle(fontSize: fontsize)),
              ),
      
            ],
            isSelected: isSelected,
            onPressed: toggleMeasure
            ),
            Padding(
              padding: const EdgeInsets.all(24.0),
              child: TextField(controller: txtHeight, keyboardType: TextInputType.number,
              decoration: InputDecoration(hintText: heightmessage),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(24.0),
              child: TextField(controller: txtWeight, keyboardType: TextInputType.number,
               decoration: InputDecoration(hintText: Weightmessage),
               ),
            ),
             ElevatedButton(child: Text('Calculate BMI',
             style: TextStyle(fontSize: fontsize),),
             onPressed:FindBMI,
             ),
             Text(result,style: TextStyle(fontSize:fontsize),)
          ],
        ),
      )
      
    );
  }

  void toggleMeasure(value){
          if(value == 0){
            isMetric = true;
            isImperial = false;
          }
            else{
              isMetric=false;
              isImperial=true;
            }
            setState(() {
              isSelected = [isMetric,isImperial];
            });
          
        }
        void FindBMI(){
          double bmi = 0;
          double height = double.tryParse(txtHeight.text) ?? 0;
          double weight = double.tryParse(txtWeight.text) ?? 0;
          if(isMetric){
            bmi = weight/(height*height);

          }
          else{
            bmi = weight*703 / (height*height);
          }
          setState(() {
            result = 'Your BMI is ' + bmi.toStringAsFixed(2);
          });
        }
}