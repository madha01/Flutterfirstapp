

import 'package:http/http.dart'as http;
import 'dart:convert';

import 'package:madhav_fitness/data/weather.dart';

class HttpHelper{
//https://api.openweathermap.org/data/2.5/
//weather?q=delhi&appid=e416583f28602184e1154cf2ed4e6625
final String authority = 'api.openweathermap.org';
final String path = 'data/2.5/weather';
final String apikey = 'e416583f28602184e1154cf2ed4e6625'; 
Future<Weather> getWeather(String location) async{
Map<String,dynamic> parameters = {'q':location, 'appId':apikey};
Uri uri = Uri.https(authority,path,parameters);
http.Response result = await http.get(uri);
Map<String, dynamic> data = json.decode(result.body);
Weather weather = Weather.fromJson(data);


return weather;

}

}
