import 'package:flutter/material.dart';
import 'package:madhav_fitness/screens/bmi_screen.dart';
import 'package:madhav_fitness/screens/intro_screen.dart';
void main(){
  runApp(GlobelApp());

}

class GlobelApp extends StatelessWidget {
  const GlobelApp
  ({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
    debugShowCheckedModeBanner: false,
    routes: {
      '/':(context)=>IntroScreen(),
      '/bmi':(context)=>Bmiscreen(),
      
    },
    initialRoute: '/',
    
    );
    

    
  }
}